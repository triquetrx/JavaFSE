package com.cognizant.springlearn.controllers;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.springlearn.SpringlearnApplication;
import com.cognizant.springlearn.exception.CountryNotFoundException;
import com.cognizant.springlearn.model.Country;
import com.cognizant.springlearn.service.CountryService;

@RestController
public class CountryController {

	private static Logger log = LoggerFactory.getLogger(SpringlearnApplication.class);

	private ApplicationContext ctx = new ClassPathXmlApplicationContext("config.xml");

	public CountryController() {
		log.info("Call to access countries");
	}

	@SuppressWarnings("unchecked")
	@GetMapping("/country")
	public List<Country> getAllCountries() {
		return (List<Country>) ctx.getBean("countryList");
	}

	@GetMapping("/country/{code}")
	public Optional<Country> getCountry(@PathVariable("code") String code) throws CountryNotFoundException {
		return CountryService.getCountry(code);
	}

}
