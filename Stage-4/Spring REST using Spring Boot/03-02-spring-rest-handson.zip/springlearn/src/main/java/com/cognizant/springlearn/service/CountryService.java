package com.cognizant.springlearn.service;

import java.util.List;
import java.util.Optional;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Service;

import com.cognizant.springlearn.exception.CountryNotFoundException;
import com.cognizant.springlearn.model.Country;

@Service
public class CountryService {
	
	private static ApplicationContext context;
	
	@SuppressWarnings("unchecked")
	public static Optional<Country> getCountry(String code) throws CountryNotFoundException{
		context=new ClassPathXmlApplicationContext("config.xml");
		List<Country> country = (List<Country>) context.getBean("countryList");
		for(Country dummy:country) {
			if(code.equalsIgnoreCase(dummy.getCode())) {
				return Optional.ofNullable(dummy);
			}
		}
		try {
		    throw new CountryNotFoundException("Country Not Found");
			}
			finally{
				
			}
	}
	
}
