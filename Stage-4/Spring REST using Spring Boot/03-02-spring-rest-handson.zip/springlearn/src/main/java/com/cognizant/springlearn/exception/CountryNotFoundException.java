package com.cognizant.springlearn.exception;

public class CountryNotFoundException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public CountryNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	
}
