package com.cognizant.loans.model;

import lombok.Data;

public @Data class Loan {

	private String loanAccount;
	private String type;
	private double loan;
	private double emi;
	private long tenure;

	public Loan(String loanAccount, String type, double loan, double emi, long tenure) {
		super();
		this.loanAccount = loanAccount;
		this.type = type;
		this.loan = loan;
		this.emi = emi;
		this.tenure = tenure;
	}

}
