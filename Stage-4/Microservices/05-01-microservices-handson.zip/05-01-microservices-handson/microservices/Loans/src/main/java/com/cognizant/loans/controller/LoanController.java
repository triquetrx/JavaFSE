package com.cognizant.loans.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.loans.model.Loan;
import com.cognizant.loans.service.LoanService;

@RestController
public class LoanController {
	
	@Autowired
	LoanService service;

	@GetMapping("loans")
	public List<Loan> getAllLoans() {
		return service.getAllLoans();
	}
	
	@GetMapping("loans/{accNumber}")
	public Loan getByAccNumber(@PathVariable String accNumber) {
		return service.getLoanDetails(accNumber);
	}
	
}
