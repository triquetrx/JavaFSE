package com.cognizant.loans.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.cognizant.loans.model.Loan;

@Service
public class LoanService {
	
	private static List<Loan> loans;
	
	static {
		loans = new ArrayList<>();
		
		loans.add(new Loan("H00987987972342", "car", 400000, 3258, 18));
		loans.add(new Loan("H00987987972343", "car", 450000, 3458, 18));
	}
	
	public List<Loan> getAllLoans(){
		return loans;
	}
	
	public Loan getLoanDetails(String accNumber) {
		for(Loan loan:loans) {
			if(loan.getLoanAccount().equalsIgnoreCase(accNumber)) {
				return loan;
			}
		}
		return null;
	}

}
