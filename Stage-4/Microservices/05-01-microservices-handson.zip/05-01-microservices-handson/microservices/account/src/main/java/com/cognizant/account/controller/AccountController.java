package com.cognizant.account.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.account.model.BankAccount;
import com.cognizant.account.service.AccountService;

@RestController
public class AccountController {
	
	@Autowired
	AccountService service;
	
	@GetMapping(value = "accounts")
	public List<BankAccount> getAccounts() {
		return service.getAll();
	}
	
	@GetMapping(value = "accounts/{accountNumber}")
	public BankAccount getAccountDetail(@PathVariable String accountNumber) {
		return service.getDetails(accountNumber);
	}

}
