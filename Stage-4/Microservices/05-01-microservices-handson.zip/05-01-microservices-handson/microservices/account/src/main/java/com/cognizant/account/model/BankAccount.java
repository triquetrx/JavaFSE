package com.cognizant.account.model;

import lombok.Data;

public @Data class BankAccount {

	private String number;
	private String type;
	private double balance;

	public BankAccount(String number, String type, double balance) {
		super();
		this.number = number;
		this.type = type;
		this.balance = balance;
	}

}
