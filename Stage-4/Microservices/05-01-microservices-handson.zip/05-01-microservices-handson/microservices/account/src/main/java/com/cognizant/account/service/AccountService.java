package com.cognizant.account.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.cognizant.account.model.BankAccount;

@Service
public class AccountService {
	
	private static List<BankAccount> accounts;
	
	static {
		accounts = new ArrayList<>();
		
		accounts.add(new BankAccount("00987987973432", "savings", 234343d));
		accounts.add(new BankAccount("00987987973433", "savings", 34343d));
		accounts.add(new BankAccount("00987987973434", "savings", 2343d));
		accounts.add(new BankAccount("00987987973435", "current", 934343.59d));
	}

	public List<BankAccount> getAll(){
		return accounts;
	}
	
	public BankAccount getDetails(String number) {
		for(BankAccount account:accounts) {
			if(account.getNumber().equalsIgnoreCase(number)) {
				return account;
			}
		}
		return null;
	}
	
}
